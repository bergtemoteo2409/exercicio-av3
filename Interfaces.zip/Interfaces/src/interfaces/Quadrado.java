package interfaces;

public Quadrado (int lado) {
      super( );
      this.lado = lado;
}

   @Override
     public double calculaArea( ) {
return lado * lado;
    }

}


